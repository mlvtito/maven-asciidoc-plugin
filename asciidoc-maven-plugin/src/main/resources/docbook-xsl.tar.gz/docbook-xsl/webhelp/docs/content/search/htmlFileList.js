//List of files which are indexed.
fl = new Array();
fl["0"]= "ch04.html";
fl["1"]= "ch05s01.html";
fl["2"]= "ch03s02.html";
fl["3"]= "index.html";
fl["4"]= "ch03s01.html";
fl["5"]= "ch01.html";
fl["6"]= "ch02.html";
fl["7"]= "ch02s01.html";
fl["8"]= "ch02s03.html";
fl["9"]= "ch05.html";
fl["10"]= "ch03.html";
fl["11"]= "ch02s05.html";
fl["12"]= "ch02s04.html";
fl["13"]= "ch02s02.html";
fl["14"]= "ch05s02.html";
var doStem = true